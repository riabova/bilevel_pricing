import gen_utils

gen_utils.generate(6, 4, seed=1)