import bnb_v2
import Graph
import bilevel_v5
import bilevel_v4
import gen_utils
import time
import csv
import numpy as np
import os, sys
import matplotlib.pyplot as plt
from dataclasses import dataclass

@dataclass
class Item:
    def __init__(self, k, l, wt, util, bp, p):
        self.k = k
        self.type = l
        self.w = wt
        self.ul = util
        self.lb = bp
        self.price = p
        #self.ui = inc

def gen_utils(K: int, P: int, G: Graph.Graph, seed: int, write=False, path="D:\\Study\\Ph.D\\Projects\\Bilevel Optimization\\data\\utils\\"):
    np.random.seed(seed)
    d = max(G.dist.values())
    base_price = np.random.uniform(d/4, d, P)
    price = [np.random.uniform(base_price[i], 1.5 * base_price[i]) for i in range(P)]
    #utils = np.transpose([np.random.normal(mu, 30, K) for mu in base_price])
    #plt.plot(np.random.beta(2, 5, K))
    #plt.show()
    utils = np.transpose([np.random.beta(1, 5, K)*base_price[p] + 1.2*base_price[p] for p in range(P)])
    if write:
        with open(path + 'up_k%d_p%d_s%d.txt' % (K, P, seed), 'w') as f:
            f.write("%d %d \n" % (K, P))
            for line in utils:
                f.write(" ".join([str(x) for x in line]) + "\n")
    return base_price, price, utils

G = Graph.Graph()
S=3

#bnbTree.plotRoute()
def get_sol_info(file):
    G = Graph.Graph()
    S=2 #change!
    G.read1(file, S=S, seed=1)
    q = [G.q]*G.r
    L = 4
    h = np.random.uniform(0.01*G.q, 0.05*G.q, L)
    items = []
    Lk = []
    #kmS = 100*np.mean(list(G.dist.values())) #bad!
    #inconvs = [[kmS/G.dist[max(k, s), min(k, s)] for s in range(G.n - S, G.n)] for k in range(1, G.n - S)]
    bprices, prices, utils = gen_utils(G.n - S - 1, L, G, seed=1, write=True)
    inconvs = [[max(prices) for s in range(G.n - S, G.n)] for k in range(1, G.n - S)]
    k = 0
    for u_p in utils:
        k += 1
        lk = []
        for l in range(L):
            if u_p[l] > 0:
                x = Item(k, l, h[l], u_p[l], bprices[l], prices[l])
                items.append(x)
                lk.append(len(items) - 1)
        Lk.append(lk)
    modelInf = bilevel_v5.getModel(G, items, Lk, inconvs, S, G.r, q)
    dThrshd = 2 #change!
    bnbTree = bnb_v2.BNB(G, modelInf[0], modelInf[1], modelInf[2], modelInf[3], modelInf[4], modelInf[5], items, Lk, inconvs, L, dThrshd)
    #bnbTree.solve()
    #bnbTree.printSol()
    bnbTree.store_sol_info()
    return [bnbTree.profit, bnbTree.rCost, bnbTree.time, bnbTree.gap]

#test over instances
'''path = "D:\Study\Ph.D\Projects\Bilevel Optimization\data\CVRP_A\\"
f = csv.writer(open(r"D:\Study\Ph.D\Projects\Bilevel Optimization\data\results\setA_vrp_p2.csv", "w", encoding="utf-16"), lineterminator="\n")
f.writerow(["Instance", "Profit", "Routing Cost", "Runtime", "Gap"])
for file in os.listdir("D:\Study\Ph.D\Projects\Bilevel Optimization\data\CVRP_A\\"):
    sol_info = get_sol_info(path + file)
    f.writerow([file] + sol_info)'''

#number of products

#f = csv.writer(open(r"D:\Study\Ph.D\Projects\Bilevel Optimization\data\results\setA_vrp_p2.csv", "w", encoding="utf-16"), lineterminator="\n")
#f.writerow(["Products", "Runtime"])
#for l in range(1, 10):
G = Graph.Graph()
S=3 #change!
G.read1("D:\Study\Ph.D\Projects\Bilevel Optimization\data\CVRP_E\E-n22-k4.vrp", S=S, seed=1)
q = [G.q]*G.r
L = 5
h = np.random.uniform(0.01*G.q, 0.05*G.q, L)
items = []
Lk = []
#kmS = 100*np.mean(list(G.dist.values())) #bad!
#inconvs = [[kmS/G.dist[max(k, s), min(k, s)] for s in range(G.n - S, G.n)] for k in range(1, G.n - S)]
bprices, prices, utils = gen_utils(G.n - S - 1, L, G, seed=1, write=True)
inconvs = [[max(prices) for s in range(G.n - S, G.n)] for k in range(1, G.n - S)]
k = 0
for u_p in utils:
    k += 1
    lk = []
    for l in range(L):
        if u_p[l] > 0:
            x = Item(k, l, h[l], u_p[l], bprices[l], prices[l])
            items.append(x)
            lk.append(len(items) - 1)
    Lk.append(lk)
modelInf = bilevel_v5.getModel(G, items, Lk, inconvs, S, G.r, q)
dThrshd = 2 #change!
start = time.time()
bnbTree = bnb_v2.BNB(G, modelInf[0], modelInf[1], modelInf[2], modelInf[3], modelInf[4], modelInf[5], items, Lk, inconvs, L, dThrshd)
bnbTree.solve()
stop = time.time() - start
#print("Solved in %g" % (time.time() - start))
#bnbTree.printSol()
#bnbTree.plotRoute()
bnbTree.store_sol_info()
print(bnbTree.profit, bnbTree.rCost, stop)